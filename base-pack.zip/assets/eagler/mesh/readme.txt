THESE ARE NOT DOOM/GMOD MODELS!

The FNAW skins are stored in a proprietary format created by lax1dude.

The format is a container for raw OpenGL vertex buffer and index buffer data intended to be copied directly into the GPU's memory, along with a small amount of metadata.

Data is rendered in GL_TRIANGLES mode using glDrawElements.

See "net/lax1dude/eaglercraft/v1_8/opengl/EaglerMeshLoader.java" and "net/lax1dude/eaglercraft/v1_8/opengl/HighPolyMesh.java" for more details.